local Backend = {}
Backend.__index = Backend

local function valid(value)
    if value == nil then return false end
    local ok, result = pcall(function() return value:IsValid() end)
    return ok and result == true
end

local function identity(value)
    return valid(value) and tostring(value:GetAddress()) or nil
end

function Backend.new(config, log)
    local source = debug.getinfo(1, "S").source
    local scripts = source:sub(1, 1) == "@" and source:sub(2):match("^(.*[/\\])")
    local focus, focusError
    if scripts then
        local modRoot = scripts:gsub("Scripts[/\\]$", "")
        focus, focusError = package.loadlib(config.focus_dll or (modRoot .. "lib/pbzinput-focus.dll"),
            "pbz_input_is_foreground")
    end
    local instance = setmetatable({config = config, log = log or print, objects = {}, functions = {},
        missing = {}, controller = nil, pawn = nil, subsystem = nil, captured = {},
        names = {}, key_dimensions = {}, focus_probe = focus, generation = 0, config_generation = 0,
        state = {ready = false, gameplay = false}}, Backend)
    if not focus and config.require_foreground ~= false then
        instance.log("Foreground probe unavailable; gameplay routing stays inactive: " .. tostring(focusError))
    end
    return instance
end

function Backend:report(key, message)
    if self.missing[key] == message then return end
    self.missing[key] = message
    self.log(message)
end

function Backend:object(path, className)
    local object = self.objects[path]
    if not valid(object) then
        object = StaticFindObject(path)
        if not valid(object) and path:sub(1, 8) ~= "/Script/" then
            local short = path:match("%.([^.:]+)$") or path:match("/([^/]+)$")
            local function matches(candidate)
                if not valid(candidate) then return false end
                local found = candidate:GetFullName():gsub("^%S+ ", "")
                return found == path or found == path .. "." .. short
            end
            if not className then
                if short:match("^IMC_") then className = "InputMappingContext"
                elseif short:match("^IA_") then className = "InputAction" end
            end
            if className then
                local candidate = FindObject(className, short)
                if matches(candidate) then object = candidate
                else
                    for _, item in ipairs(FindAllOf(className) or {}) do
                        if matches(item) then object = item; break end
                    end
                end
            end
        end
        if valid(object) then self.objects[path] = object end
    end
    if not valid(object) then error("Object is not loaded: " .. path, 0) end
    return object
end

function Backend:invoke(object, path, ...)
    if not valid(object) then error("Receiver unavailable for " .. path, 0) end
    local fn = self.functions[path]
    if not valid(fn) then
        fn = self:object(path)
        local functionClass = self:object("/Script/CoreUObject.Function")
        if not fn:IsA(functionClass) then error("Not a UFunction: " .. path, 0) end
        self.functions[path] = fn
    end
    return object:CallFunction(fn, ...)
end

function Backend:library(name)
    return self:object("/Script/" .. name:gsub("%.", ".Default__", 1))
end

function Backend:refresh()
    local controller = self.controller
    if not valid(controller) then
        controller = nil
        for _, candidate in ipairs(FindAllOf("PlayerController") or {}) do
            if valid(candidate) and self:invoke(candidate, "/Script/Engine.Controller:IsLocalPlayerController") then
                controller = candidate
                break
            end
        end
    end
    if not valid(controller) then
        self:retire()
        self.state = {ready = false, gameplay = false, generation = self.generation}
        return false
    end
    local pawn = self:invoke(controller, "/Script/Engine.Controller:K2_GetPawn")
    local changed = identity(controller) ~= identity(self.controller) or identity(pawn) ~= identity(self.pawn)
    if changed then
        self:retire()
        self.controller, self.pawn, self.subsystem = controller, pawn, nil
        self.generation = self.generation + 1
        self.log("Local player changed; generation=" .. self.generation)
    end
    if not valid(self.subsystem) then
        local library = self:library("Engine.SubsystemBlueprintLibrary")
        self.subsystem = self:invoke(library,
            "/Script/Engine.SubsystemBlueprintLibrary:GetLocalPlayerSubSystemFromPlayerController",
            controller, self:object("/Script/EnhancedInput.EnhancedInputLocalPlayerSubsystem"))
    end
    local paused = self:invoke(self:library("Engine.GameplayStatics"),
        "/Script/Engine.GameplayStatics:IsGamePaused", controller)
    local cursor = controller.bShowMouseCursor == true
    local foreground = self.config.require_foreground == false or
        (type(self.focus_probe) == "function" and self.focus_probe(true) == true)
    self.state = {ready = valid(pawn) and valid(self.subsystem), has_pawn = valid(pawn),
        paused = paused == true, cursor = cursor, foreground = foreground, generation = self.generation,
        gameplay = valid(pawn) and paused ~= true and not cursor and foreground}
    if self.state.gameplay and self.config.enabled ~= false then
        if self.config.dynamic_capture then self:prepare_dynamic_capture() end
        self:take_capture()
    else self:release_capture() end
    return self.state.ready
end

function Backend:take_capture()
    if not valid(self.subsystem) then return end
    for _, entry in ipairs(self.dynamic_contexts or self.config.capture_contexts or {}) do
        local path = type(entry) == "string" and entry or entry.path
        local ok, result = pcall(function()
            local context = self:object(path)
            for removal = 1, math.max(1, type(entry) == "table" and entry.registration_count or 1) do
                local priority = {}
                if not self:invoke(self.subsystem,
                    "/Script/EnhancedInput.EnhancedInputSubsystemInterface:HasMappingContext", context, priority) then return end
                if type(priority.OutFoundPriority) ~= "number" then
                    error("HasMappingContext did not return OutFoundPriority", 0)
                end
                self:invoke(self.subsystem, "/Script/EnhancedInput.EnhancedInputSubsystemInterface:RemoveMappingContext",
                    context, {bIgnoreAllPressedKeysUntilRelease = false, bForceImmediately = true,
                        bNotifyUserSettings = false})
                local previous = self.captured[path]
                self.captured[path] = {object = context, priority = priority.OutFoundPriority,
                    removals = (previous and previous.removals or 0) + 1}
            end
        end)
        if not ok then error("Capture failed for " .. path .. ": " .. tostring(result), 0) end
    end
end

function Backend:retire()
    if self.on_retire then self.on_retire() end
    self:release_capture()
    self.controller, self.pawn, self.subsystem = nil, nil, nil
end

function Backend:release_capture()
    if (next(self.captured) or self.dynamic_config) and self.on_release then self.on_release() end
    local failed = {}
    if valid(self.subsystem) then
        for path, entry in pairs(self.captured) do
            if valid(entry.object) then
                local ok, err = pcall(function()
                    while entry.removals > 0 do
                        self:invoke(self.subsystem, "/Script/EnhancedInput.EnhancedInputSubsystemInterface:AddMappingContext",
                            entry.object, entry.priority, {bIgnoreAllPressedKeysUntilRelease = false,
                                bForceImmediately = true, bNotifyUserSettings = false})
                        entry.removals = entry.removals - 1
                    end
                end)
                if not ok then
                    failed[path] = entry
                    self:report("restore:" .. path, "Context restore failed: " .. tostring(err))
                end
            end
        end
    end
    self.captured = failed
    if next(failed) then error("Original input context restore is incomplete; F8 retries", 0) end
    self:release_holder()
    if self.dynamic_config then
        self.dynamic_config, self.dynamic_contexts = nil, nil
        self.config_generation = self.config_generation + 1
    end
end

local function array_values(array)
    local result = {}
    array:ForEach(function(index, item) result[#result + 1] = item:get() end)
    return result
end

function Backend:hold_objects(triggers, modifiers)
    if valid(self.holder) then
        self.holder:SetPropertyValue("Triggers", triggers)
        self.holder:SetPropertyValue("Modifiers", modifiers)
        return
    end
    local actionClass = self:object("/Script/EnhancedInput.InputAction")
    local action = StaticConstructObject(actionClass, self.subsystem)
    local holder = StaticConstructObject(actionClass, self.subsystem)
    local settings = StaticConstructObject(self:object("/Script/EnhancedInput.PlayerMappableKeySettings"), action)
    if not valid(action) or not valid(holder) or not valid(settings) then
        error("Cannot create dynamic input GC holder", 0)
    end
    holder:SetPropertyValue("Triggers", triggers)
    holder:SetPropertyValue("Modifiers", modifiers)
    settings:SetPropertyValue("Metadata", holder)
    action:SetPropertyValue("PlayerMappableKeySettings", settings)
    self:invoke(self.subsystem,
        "/Script/EnhancedInput.EnhancedInputSubsystemInterface:StartContinuousInputInjectionForAction",
        action, {}, {}, {})
    self.holder, self.holder_action = holder, action
end

function Backend:release_holder()
    if valid(self.holder_action) and valid(self.subsystem) then
        self:invoke(self.subsystem,
            "/Script/EnhancedInput.EnhancedInputSubsystemInterface:StopContinuousInputInjectionForAction", self.holder_action)
    end
    for _, action in ipairs(self.context_holders or {}) do
        if valid(action) and valid(self.subsystem) then
            self:invoke(self.subsystem,
                "/Script/EnhancedInput.EnhancedInputSubsystemInterface:StopContinuousInputInjectionForAction", action)
        end
    end
    self.context_holders = nil
    self.holder, self.holder_action = nil, nil
end

function Backend:hold_contexts(contexts)
    self.context_holders = self.context_holders or {}
    for _, entry in ipairs(contexts) do
        local action = StaticConstructObject(self:object("/Script/EnhancedInput.InputAction"), self.subsystem)
        local settings = StaticConstructObject(self:object("/Script/EnhancedInput.PlayerMappableKeySettings"), action)
        if not valid(action) or not valid(settings) then error("Cannot retain mapping context", 0) end
        settings:SetPropertyValue("Metadata", self:object(entry.path))
        action:SetPropertyValue("PlayerMappableKeySettings", settings)
        self:invoke(self.subsystem,
            "/Script/EnhancedInput.EnhancedInputSubsystemInterface:StartContinuousInputInjectionForAction", action, {}, {}, {})
        self.context_holders[#self.context_holders + 1] = action
    end
end

function Backend:effective_config()
    return self.dynamic_config or self.config
end

function Backend:prepare_dynamic_capture()
    local input = self.controller.PlayerInput
    if not valid(input) then error("Local EnhancedPlayerInput unavailable", 0) end
    local mappings = input:GetPropertyValue("EnhancedActionMappings")
    local contexts = input:GetPropertyValue("AppliedInputContextData")
    if not mappings or not contexts then error("EnhancedPlayerInput runtime mappings unavailable", 0) end
    if self.dynamic_config then
        local changed = false
        contexts:ForEach(function(key, value)
            local context, data = key:get(), value:get()
            local path = context:GetFullName():gsub("^%S+ ", "")
            if not self.config.capture_filter or self.config.capture_filter(path, context, data) == true then changed = true end
        end)
        if not changed then return end
        self:release_capture()
        mappings = input:GetPropertyValue("EnhancedActionMappings")
        contexts = input:GetPropertyValue("AppliedInputContextData")
    end
    local dynamicContexts, contextActions, excludedActions = {}, {}, {}
    contexts:ForEach(function(key, value)
        local context, data = key:get(), value:get()
        local path = context:GetFullName():gsub("^%S+ ", "")
        local include = true
        if self.config.capture_filter then include = self.config.capture_filter(path, context, data) == true end
        if include then
            dynamicContexts[#dynamicContexts + 1] = {path = path, priority = data.Priority,
                registration_count = data.RegistrationCount}
        end
        context.DefaultKeyMappings.Mappings:ForEach(function(index, entry)
            local action = entry:get().Action
            if valid(action) then
                local destination = include and contextActions or excludedActions
                destination[identity(action)] = true
            end
        end)
    end)
    for action in pairs(contextActions) do
        if excludedActions[action] then
            error("Dynamic capture filter divides contexts sharing one InputAction; capture all participating contexts", 0)
        end
    end
    if #dynamicContexts == 0 then return end
    local config = {}
    for key, value in pairs(self.config) do config[key] = value end
    config.targets, config.bindings = {}, {}
    for key, value in pairs(self.config.targets) do config.targets[key] = value end
    for _, value in ipairs(self.config.bindings) do config.bindings[#config.bindings + 1] = value end
    local allTriggers, allModifiers, count = {}, {}, 0
    mappings:ForEach(function(index, entry)
        local mapping = entry:get()
        if next(excludedActions) and not contextActions[identity(mapping.Action)] then return end
        local key = mapping.Key.KeyName:ToString()
        if key == "None" then return end
        local name = "__baseline_" .. index
        local modifiers, triggers = array_values(mapping.Modifiers), array_values(mapping.Triggers)
        for _, object in ipairs(modifiers) do allModifiers[#allModifiers + 1] = object end
        for _, object in ipairs(triggers) do allTriggers[#allTriggers + 1] = object end
        config.targets[name] = {kind = "action", object = mapping.Action,
            modifier_objects = modifiers, trigger_objects = triggers}
        local dimension = self:key_dimension(key)
        if dimension == 1 then
            config.bindings[#config.bindings + 1] = {id = name,
                axis = key, trigger = "axis",
                threshold = 0.000001, priority = self.config.baseline_priority or -10000,
                outputs = {name}}
        else
            local samples = {}
            for axis = 1, dimension do samples[axis] = key .. "@" .. axis end
            config.bindings[#config.bindings + 1] = {id = name, keys = {key}, watch = samples,
                priority = self.config.baseline_priority or -10000, outputs = {name},
                evaluate = function(now, snapshot)
                    local value = {x = snapshot[samples[1]] or 0, y = snapshot[samples[2]] or 0,
                        z = samples[3] and snapshot[samples[3]] or 0}
                    local active = math.max(math.abs(value.x), math.abs(value.y), math.abs(value.z)) > 0.000001
                    return {active = active, value = value, reserve = active}
                end}
        end
        count = count + 1
    end)
    self:hold_objects(allTriggers, allModifiers)
    self:hold_contexts(dynamicContexts)
    self.dynamic_contexts, self.dynamic_config = dynamicContexts, config
    self.config_generation = self.config_generation + 1
    self.log("Runtime capture prepared: contexts=" .. #dynamicContexts .. " mappings=" .. count)
end

function Backend:key_dimension(key)
    if self.key_dimensions[key] then return self.key_dimensions[key] end
    local library, keyStruct = self:library("Engine.KismetInputLibrary"), {KeyName = FName(key)}
    local dimension = 1
    if self:invoke(library, "/Script/Engine.KismetInputLibrary:Key_IsAxis3D", keyStruct) then dimension = 3
    elseif self:invoke(library, "/Script/Engine.KismetInputLibrary:Key_IsAxis2D", keyStruct) then dimension = 2 end
    self.key_dimensions[key] = dimension
    return dimension
end

function Backend:context()
    self.state.pawn, self.state.controller = self.pawn, self.controller
    self.state.subsystem, self.state.backend = self.subsystem, self
    return self.state
end

function Backend:allowed(condition, context)
    if not condition then return true end
    if type(condition) == "function" then return condition(context) == true end
    if type(condition) == "string" then return context[condition] == true end
    for key, expected in pairs(condition) do
        if context[key] ~= expected then return false end
    end
    return true
end

function Backend:snapshot(keys)
    local result = {}
    if not valid(self.controller) then return result end
    for _, key in ipairs(keys) do
        local vectorKey, component = key:match("^(.-)@([123])$")
        if vectorKey then
            local vector = self:invoke(self.controller, "/Script/Engine.PlayerController:GetInputVectorKeyState",
                {KeyName = FName(vectorKey)})
            result[key] = vector[({"X", "Y", "Z"})[tonumber(component)]]
        elseif self:key_dimension(key) > 1 then
            local vector = self:invoke(self.controller, "/Script/Engine.PlayerController:GetInputVectorKeyState",
                {KeyName = FName(key)})
            result[key] = math.max(math.abs(vector.X), math.abs(vector.Y), math.abs(vector.Z))
        else
        local fname = self.names[key]
        if not fname then fname = FName(key); self.names[key] = fname end
        local keyStruct = {KeyName = fname}
        local value = self:invoke(self.controller, "/Script/Engine.PlayerController:GetInputAnalogKeyState", keyStruct)
        if value == 0 then
            value = self:invoke(self.controller, "/Script/Engine.PlayerController:IsInputKeyDown", keyStruct) and 1 or 0
        end
        result[key] = value
        end
    end
    return result
end

function Backend:time()
    return self:invoke(self:library("Engine.GameplayStatics"),
        "/Script/Engine.GameplayStatics:GetRealTimeSeconds", self.controller)
end

function Backend:receiver(spec)
    local name = spec.receiver or "pawn"
    if type(name) == "function" then return name(self, self:context()) end
    if name == "pawn" then return self.pawn end
    if name == "controller" then return self.controller end
    if name == "subsystem" then return self.subsystem end
    if name == "ability_input" then
        return self:invoke(self.pawn, "/Script/Engine.Actor:GetComponentByClass",
            self:object("/Script/SGameInputSystem.AbilityInputComponent"))
    end
    if name == "ability_system" then
        return self:invoke(self:library("GameplayAbilities.AbilitySystemBlueprintLibrary"),
            "/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:GetAbilitySystemComponent", self.pawn)
    end
    return self:object(name, spec.receiver_class)
end

function Backend:argument(value, context)
    if type(value) == "function" then return value(self, context) end
    if type(value) ~= "table" then return value end
    if value.object then return self:object(value.object, value.class) end
    if value.receiver then return self:receiver(value) end
    if value.fname then return FName(value.fname) end
    if value.tag then return {TagName = FName(value.tag)} end
    if value.value then return context.value end
    if value.phase then return context.phase end
    local result = {}
    for key, item in pairs(value) do result[key] = self:argument(item, context) end
    return result
end

function Backend:object_array(paths, className)
    local result = {}
    for i, path in ipairs(paths or {}) do result[i] = self:object(path, className) end
    return result
end

function Backend:dispatch(spec, phase, value, bindingId)
    if not self.state.ready then return false end
    local ok, result = pcall(function()
        if spec.kind == "action" then
            local vector = phase == "completed" and {X = 0, Y = 0, Z = 0}
                or {X = value and (value.x or value.X) or 1,
                    Y = value and (value.y or value.Y) or 0,
                    Z = value and (value.z or value.Z) or 0}
            return self:invoke(self.subsystem,
                "/Script/EnhancedInput.EnhancedInputSubsystemInterface:InjectInputVectorForAction",
                spec.object or self:object(spec.path, "InputAction"), vector,
                spec.modifier_objects or self:object_array(spec.modifiers, "InputModifier"),
                spec.trigger_objects or self:object_array(spec.triggers, "InputTrigger"))
        end
        if phase == "completed" then return true end
        if spec.kind == "lua" then
            return spec.run(self, {phase = phase, value = value, binding = bindingId,
                state = self:context()})
        end
        if spec.kind == "ability" then
            local component = self:receiver({receiver = "ability_input"})
            local method = spec.force and "ForceActivateExternalActionAbilityByTag"
                or "TryActivateExternalActionAbilityInterruptLowerByTag"
            return self:invoke(component, "/Script/SGameInputSystem.AbilityInputComponent:" .. method,
                {TagName = FName(spec.tag)},
                self:object(spec.input_action or "/PBZDeflectSystem/Input/IA_Dodge.IA_Dodge"), spec.priority or -5)
        end
        if spec.kind == "event" then
            local tag = {TagName = FName(spec.tag)}
            local payload = self:argument(spec.payload or {}, {value = value, phase = phase})
            payload.EventTag = tag
            payload.Instigator = payload.Instigator or self.pawn
            payload.Target = payload.Target or self.pawn
            payload.EventMagnitude = payload.EventMagnitude or (value and value.x) or 1
            return self:invoke(self:library("GameplayAbilities.AbilitySystemBlueprintLibrary"),
                "/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:SendGameplayEventToActor",
                self.pawn, tag, payload)
        end
        if spec.kind == "function" then
            local arguments = {}
            for i, item in ipairs(spec.args or {}) do
                arguments[i] = self:argument(item, {value = value, phase = phase})
            end
            return self:invoke(self:receiver(spec), spec.path, table.unpack(arguments, 1, #arguments))
        end
        if spec.kind == "property" then
            local receiver = self:receiver(spec)
            if not valid(receiver) then error("Property receiver unavailable", 0) end
            receiver:SetPropertyValue(spec.property, self:argument(spec.value, {value = value, phase = phase}))
            return true
        end
        error("Unsupported target kind: " .. tostring(spec.kind), 0)
    end)
    if not ok then
        self.dispatch_error = "Dispatch failed [" .. tostring(bindingId) .. "]: " .. tostring(result)
        self:report("dispatch:" .. tostring(bindingId) .. ":" .. tostring(spec.path or spec.tag),
            self.dispatch_error)
    end
    return ok, result
end

function Backend:shutdown()
    self:release_capture()
end

return Backend
