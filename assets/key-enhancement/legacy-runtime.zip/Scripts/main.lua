local Config = require("router-config")
local Backend = require("backend")
local Router = require("router")

local function log(message)
    print("[PBZInputRouter] " .. tostring(message) .. "\n")
end

local runtime = {running = true, pending = false, generation = nil, last_error = nil,
    suspended = false, hooks = {}, active = false, wait_for_release = {}}
local backend = Backend.new(Config, log)
local router = Router.new(Config, backend)
backend.on_retire = function() router:reset() end
backend.on_release = function() router:reset() end

local function uninstall_hooks()
    for path, ids in pairs(runtime.hooks) do UnregisterHook(path, ids[1], ids[2]) end
    runtime.hooks = {}
end

local function stop()
    runtime.running = false
    local restored, restoreError = pcall(function()
        router:reset()
        backend:shutdown()
    end)
    uninstall_hooks()
    if runtime.handle and type(CancelDelayedAction) == "function" then CancelDelayedAction(runtime.handle) end
    if not restored then error(restoreError, 0) end
    log("Stopped; original input contexts restored")
end

local function reload()
    if not runtime.running then return false, "Router is stopped" end
    local previous = package.loaded["router-config"]
    package.loaded["router-config"] = nil
    local ok, candidate, candidateRouter = pcall(function()
        local candidate = require("router-config")
        local candidateRouter = Router.new(candidate, backend)
        return candidate, candidateRouter
    end)
    if not ok then
        package.loaded["router-config"] = previous
        log("Configuration rejected: " .. tostring(candidate))
        return false, candidate
    end
    local restored, restoreError = pcall(function()
        router:reset()
        backend:shutdown()
    end)
    if not restored then
        package.loaded["router-config"] = previous
        runtime.suspended = true
        log("Reload suspended until original input restoration completes: " .. tostring(restoreError))
        return false, restoreError
    end
    uninstall_hooks()
    Config, router = candidate, candidateRouter
    backend.config = Config
    runtime.active, runtime.suspended = false, false
    runtime.generation, runtime.config_generation, runtime.last_error = nil, nil, nil
    log("Configuration reloaded; bindings=" .. #Config.bindings)
    return true
end

local function install_hooks()
    for _, rule in ipairs(Config.hooks or {}) do
        if not runtime.hooks[rule.path] then
            local object = StaticFindObject(rule.path)
            if object and object:IsValid() then
                local function callback(...)
                    if not runtime.running or Config.enabled == false or runtime.suspended or not backend:allowed(rule.when, backend:context()) then return end
                    if rule.evaluate then
                        local ok, result = pcall(rule.evaluate, ...)
                        if not ok then backend:report("hook:" .. rule.path, "Hook failed: " .. tostring(result)); return end
                        return result
                    end
                    return rule.value
                end
                local first, second
                if rule.path:sub(1, 8) == "/Script/" then
                    first, second = RegisterHook(rule.path, function() end, callback)
                else first, second = RegisterHook(rule.path, callback) end
                runtime.hooks[rule.path] = {first, second}
                log("Return hook installed: " .. rule.path)
            end
        end
    end
end

local function tick()
    if not runtime.running or runtime.suspended then return end
    local ok, err = pcall(function()
        if not backend:refresh() then runtime.active = false; return end
        if backend.config_generation ~= runtime.config_generation then
            router:reset()
            router = Router.new(backend:effective_config(), backend)
            runtime.config_generation = backend.config_generation
            runtime.active = false
        end
        local context = backend:context()
        install_hooks()
        if context.generation ~= runtime.generation then
            router:reset()
            runtime.generation = context.generation
            runtime.active = false
        end
        if Config.enabled == false or not context.gameplay then
            router:reset()
            runtime.active = false
            return
        end
        local snapshot = backend:snapshot(router:keys())
        if not runtime.active then
            runtime.wait_for_release = {}
            for key, value in pairs(snapshot) do
                if math.abs(value) > 0.001 then runtime.wait_for_release[key] = true end
            end
            runtime.active = true
        end
        for key in pairs(runtime.wait_for_release) do
            if math.abs(snapshot[key] or 0) <= 0.001 then runtime.wait_for_release[key] = nil
            else snapshot[key] = 0 end
        end
        backend.dispatch_error = nil
        router:step(backend:time(), snapshot, context)
        if backend.dispatch_error then error(backend.dispatch_error, 0) end
    end)
    if not ok and runtime.last_error ~= tostring(err) then
        pcall(function() router:reset() end)
        pcall(function() backend:shutdown() end)
        runtime.suspended = true
        runtime.active = false
        runtime.last_error = tostring(err)
        log("Routing suspended; original contexts restored: " .. runtime.last_error .. "; F8 retries")
    elseif ok then runtime.last_error = nil end
end

if type(LoopInGameThreadAfterFrames) == "function" and EngineTickAvailable ~= false then
    runtime.handle = LoopInGameThreadAfterFrames(1, tick)
    log("Game-thread frame scheduler ready")
elseif type(ExecuteInGameThreadAfterFrames) == "function" and EngineTickAvailable ~= false then
    local frame
    frame = function()
        tick()
        if runtime.running then runtime.handle = ExecuteInGameThreadAfterFrames(1, frame) end
    end
    runtime.handle = ExecuteInGameThreadAfterFrames(1, frame)
    log("Game-thread frame scheduler ready")
else
    LoopAsync(8, function()
        if not runtime.running then return true end
        if runtime.pending then return false end
        runtime.pending = true
        ExecuteInGameThread(function()
            runtime.pending = false
            tick()
        end)
        return false
    end)
    log("Game-thread queued scheduler ready (8 ms polling)")
end

RegisterKeyBind(Key.F8, function()
    if not runtime.running then return end
    ExecuteInGameThread(function()
        if not runtime.running then return end
        if runtime.suspended then Config.enabled = true; runtime.suspended = false
        else Config.enabled = not (Config.enabled ~= false) end
        router:reset()
        runtime.active = false
        if Config.enabled == false then backend:shutdown() end
        log(Config.enabled and "Routing enabled" or "Routing disabled; original contexts restored")
    end)
end)

RegisterKeyBind(Key.F7, function()
    if runtime.running then ExecuteInGameThread(reload) end
end)

log("Loaded; F8 toggles routing, F7 reloads configuration, bindings=" .. #(Config.bindings or {}))

return {backend = backend, stop = stop, reload = reload}
