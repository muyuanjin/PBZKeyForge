local Router = {}
Router.__index = Router

local kinds = { down=true, press=true, release=true, tap=true, hold=true,
    pulse=true, multi_tap=true, sequence=true, axis=true, toggle=true }

local function vector(value)
    if type(value) == "table" then
        return { x=value.x or value[1] or 0, y=value.y or value[2] or 0,
            z=value.z or value[3] or 0 }
    end
    return { x=value == nil and 1 or value, y=0, z=0 }
end

local function magnitude(v)
    return math.max(math.abs(v.x), math.abs(v.y), math.abs(v.z))
end

local function down(snapshot, key, threshold)
    local v = snapshot[key]
    return v == true or (type(v) == "number" and math.abs(v) >= threshold)
end

local function chord(snapshot, keys, threshold)
    for _, key in ipairs(keys or {}) do
        if not down(snapshot, key, threshold) then return false end
    end
    return true
end

local function consumes(binding)
    if binding.consume == true then return binding.keys or {} end
    return type(binding.consume) == "table" and binding.consume or {}
end

function Router.new(config, backend)
    assert(type(config.targets) == "table", "targets must be a table")
    assert(type(config.bindings) == "table", "bindings must be an array")
    local self = setmetatable({ config=config, backend=backend, rules={},
        samples={}, previous={}, lastTime=nil }, Router)
    local ids, keys = {}, {}
    local function add(key)
        assert(type(key) == "string" and key ~= "", "invalid input key")
        keys[key] = true
    end
    for index, binding in ipairs(config.bindings) do
        assert(binding.id and not ids[binding.id], "binding id missing or duplicated")
        ids[binding.id] = true
        local kind = binding.trigger or "down"
        assert(kinds[kind] or type(binding.evaluate) == "function", "unknown trigger: " .. kind)
        assert(binding.axis or #(binding.keys or {}) > 0 or kind == "sequence"
            or binding.evaluate, "binding needs an input")
        if kind == "sequence" then assert(#(binding.steps or {}) > 0, "empty sequence") end
        for _, key in ipairs(binding.keys or {}) do add(key) end
        if binding.axis then add(binding.axis) end
        for _, step in ipairs(binding.steps or {}) do
            if type(step) == "string" then add(step)
            else for _, key in ipairs(step) do add(key) end end
        end
        for _, key in ipairs(binding.watch or {}) do add(key) end
        for _, key in ipairs(consumes(binding)) do add(key) end
        assert(#(binding.outputs or {}) > 0, "binding needs outputs")
        for _, output in ipairs(binding.outputs) do
            local name = type(output) == "string" and output or output.target
            assert(config.targets[name], "unknown target: " .. tostring(name))
        end
        self.rules[#self.rules+1] = { binding=binding, index=index, state={} }
    end
    table.sort(self.rules, function(a,b)
        local ap, bp = a.binding.priority or 0, b.binding.priority or 0
        if ap ~= bp then return ap > bp end
        local an, bn = #(a.binding.keys or {}), #(b.binding.keys or {})
        return an ~= bn and an > bn or (an == bn and a.index < b.index)
    end)
    for key in pairs(keys) do self.samples[#self.samples+1] = key end
    table.sort(self.samples)
    return self
end

function Router:keys() return self.samples end

local function evaluate(binding, st, now, snapshot, context)
    if binding.evaluate then return binding.evaluate(now, snapshot, context, st) end
    local kind, threshold = binding.trigger or "down", binding.threshold or 0.5
    local held = chord(snapshot, binding.keys, threshold)
    if binding.axis then held = held and down(snapshot, binding.axis, threshold) end
    local pressed, released = held and not st.held, not held and st.held
    st.held = held
    if pressed then st.since = now end
    local active, pulse, value = false, false, 1
    if kind == "down" then active, pulse = held, pressed
    elseif kind == "press" then active, pulse = pressed, pressed
    elseif kind == "release" then active, pulse = released, released
    elseif kind == "tap" then
        pulse = released and now - st.since <= (binding.seconds or 0.25)
        active = pulse
    elseif kind == "hold" then
        active = held and now - st.since >= (binding.seconds or 0.35)
        pulse = active and not st.active
    elseif kind == "pulse" then
        if held and (pressed or now >= (st.nextPulse or now)) then
            pulse = true
            st.nextPulse = now + (binding.interval or 0.15)
        end
        active = pulse
    elseif kind == "multi_tap" then
        if pressed then
            st.count = st.lastTap and now - st.lastTap <= (binding.interval or 0.3)
                and (st.count or 0) + 1 or 1
            st.lastTap = now
            if st.count >= (binding.count or 2) then pulse=true; st.count=0 end
        end
        active = pulse
    elseif kind == "toggle" then
        if pressed then st.toggled = not st.toggled end
        active, pulse = st.toggled or false, pressed and st.toggled or false
    elseif kind == "axis" then
        active, pulse = held, pressed
        value = type(snapshot[binding.axis]) == "number" and snapshot[binding.axis] or 0
    elseif kind == "sequence" then
        if st.lastStep and now - st.lastStep > (binding.interval or 0.5) then st.step=0 end
        local progress = st.step or 0
        local expected = binding.steps[progress+1]
        local stepKeys = type(expected) == "string" and {expected} or expected
        local stepDown = chord(snapshot, stepKeys, threshold)
        local stepWasDown = chord(st.previousSnapshot or {}, stepKeys, threshold)
        if stepDown and not stepWasDown then
            st.step, st.lastStep = progress+1, now
            if st.step == #binding.steps then pulse=true; st.step=0 end
        end
        st.previousSnapshot = {}
        for key,v in pairs(snapshot) do st.previousSnapshot[key]=v end
        active = pulse
        held = (st.step or 0) > 0 or pulse
    end
    st.active = active
    return { active=active, pulse=pulse, value=value,
        reserve=held or released and (kind == "tap" or kind == "release") }
end

function Router:step(now, snapshot, context)
    assert(type(now) == "number", "clock must be numeric")
    if self.lastTime and now < self.lastTime then self:reset() end
    self.lastTime = now
    local levels, reserved = {}, {}
    for _, rule in ipairs(self.rules) do
        local b, st = rule.binding, rule.state
        local blocked = false
        for _, key in ipairs(b.keys or {}) do if reserved[key] then blocked=true end end
        if b.axis and reserved[b.axis] then blocked=true end
        local allowed = not b.when or self.backend:allowed(b.when, context)
        local result = evaluate(b, st, now, snapshot, context)
        if not blocked and allowed then
            if result.reserve then
                for _, key in ipairs(consumes(b)) do reserved[key]=true end
            end
            if result.active then
                for _, output in ipairs(b.outputs) do
                    local name = type(output) == "string" and output or output.target
                    local target = self.config.targets[name]
                    local v = type(result.value) == "table" and vector(result.value)
                        or vector(type(output) == "table" and output.value or nil)
                    local scale = type(result.value) == "number" and result.value or 1
                    v.x, v.y, v.z = v.x*scale, v.y*scale, v.z*scale
                    if target.kind == "action" then
                        local level = levels[name]
                        if not level then
                            level={ value={x=0,y=0,z=0}, binding=b.id }
                            levels[name]=level
                        end
                        level.value.x = level.value.x + v.x
                        level.value.y = level.value.y + v.y
                        level.value.z = level.value.z + v.z
                    elseif result.pulse then
                        self.backend:dispatch(target, "triggered", v, b.id)
                    end
                end
            end
        end
    end
    for name, level in pairs(levels) do
        local target, v = self.config.targets[name], level.value
        if target.value_type == "bool" then
            v.x, v.y, v.z = magnitude(v) > 0 and 1 or 0, 0, 0
        elseif target.clamp then
            for _, axis in ipairs({"x","y","z"}) do
                v[axis]=math.max(-target.clamp, math.min(target.clamp, v[axis]))
            end
        end
        if magnitude(v) == 0 then levels[name]=nil
        else self.backend:dispatch(target, self.previous[name] and "triggered" or "started",
            v, level.binding) end
    end
    for name, previous in pairs(self.previous) do
        if not levels[name] then
            self.backend:dispatch(self.config.targets[name], "completed", {x=0,y=0,z=0}, previous.binding)
        end
    end
    self.previous = levels
end

function Router:reset()
    for name, previous in pairs(self.previous) do
        self.backend:dispatch(self.config.targets[name], "completed", {x=0,y=0,z=0}, previous.binding)
    end
    self.previous, self.lastTime = {}, nil
    for _, rule in ipairs(self.rules) do rule.state={} end
end

return Router
